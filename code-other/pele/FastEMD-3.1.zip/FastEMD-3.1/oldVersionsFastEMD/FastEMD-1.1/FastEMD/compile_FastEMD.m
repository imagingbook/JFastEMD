mex -O -DNDEBUG emd_hat_metric_mex.cxx emd_hat_check_and_extract_mex.cxx emd_hat.cpp
mex -O -DNDEBUG emd_hat_mex.cxx emd_hat_check_and_extract_mex.cxx emd_hat.cpp

